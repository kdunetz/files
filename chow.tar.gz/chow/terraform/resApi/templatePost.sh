export CAM_HOST=10.215.20.112
export CAM_USER=admin
export CAM_PASSWORD=admin
token=`curl -k -X POST -H "Content-Type: application/x-www-form-urlencoded;charset=UTF-8" -d "grant_type=password&username=${CAM_USER}&password=${CAM_PASSWORD}&scope=openid" https://${CAM_HOST}:8443/idprovider/v1/auth/identitytoken | jq -r '.access_token'`
export CAM_BEARER_TOKEN=$token 
echo $CAM_BEARER_TOKEN
otherStuff=`curl -k -X GET -H "Authorization: Bearer ${CAM_BEARER_TOKEN}" https://${CAM_HOST}:30000/cam/tenant/api/v1/tenants/getTenantOnPrem`
echo $otherStuff
tenantId=$otherStuff | jq  -r '.id'
echo "TENANT ==> $tenantId"
icp_team=echo $otherStuff | jq  -r '.namespaces[0].teamId'
echo "TEAM ==> $icp_team"

#tenant=`curl -k -X GET -H "Authorization: Bearer ${CAM_BEARER_TOKEN}" https://${CAM_HOST}:30000/cam/tenant/api/v1/tenants/getTenantOnPrem | jq -r '.id'`
echo $tenant
