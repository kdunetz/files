import requests
import json

print("Cloud Automation Manager APIs - Python Script")

protocol='https://'
host='10.215.20.112'
camPort='30000'
icpPort='8443'
user='admin'
pw='admin'

cam=protocol + host + ":" + camPort
icp=protocol + host + ":" + icpPort

#get access token for cam
postdata = "grant_type=password&username=" + user + "&password=" + pw + "&scope=openid"
head = {'Content-Type':'application/x-www-form-urlencoded', 'Accept':'application/json', "charset" : "UTF-8"}
ret = requests.post(icp + "/idprovider/v1/auth/identitytoken", data=postdata, headers=head, verify=False)
access_token=ret.json()["access_token"]
print("access_token", access_token)

#GET tenantId, team and namespace from CAM
head = {"Authorization": "bearer " + access_token}
ret = requests.get(cam + "/cam/tenant/api/v1/tenants/getTenantOnPrem", headers=head, verify=False)
print(ret.json())
tenantId = ret.json()["id"]
namespace = ret.json()["namespaces"][1]["uid"]
if user != 'admin': team = ret.json()["namespaces"][1]["teamId"]
else : team = 'all'
print("tenantId", tenantId)
print("team", team)
print("namespace", namespace)
namespace="default"


#GET templates from CAM
#parameters={"tenantId":tenantId, "ace_orgGuid":team}
#head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
#ret = requests.get(cam + "/cam/api/v1/templates", headers=head, params=parameters, verify=False)
#templates=json.dumps(ret.json())
#print("templates", templates)

#GET templates from CAM with name filter
parameters={"tenantId":tenantId, "ace_orgGuid":team, "filter":'{"where": {"name": "Tomcat" }}'}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/templates", headers=head, params=parameters, verify=False)
templates=json.dumps(ret.json())
templateId=ret.json()[0]["id"]
print("templates", templates)
print("template ID", templateId)

#GET cloudconnections from CAM
parameters={"tenantId":tenantId, "ace_orgGuid":team}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/cloudconnections", headers=head, params=parameters, verify=False)
cloudConnections=json.dumps(ret.json())
#print("cloudConnections", cloudConnections)
cloudConnectionId=ret.json()[0]["id"]
print("cloudConnections ID", cloudConnectionId)


#Deploy the template
token="FQoDYXdzEM3//////////wEaDK2VNVoB/3or0NwVRSK5Atvc5mVXut9gk+0NwLX6z7eNMeV15tT5i8kO5Tzh1DzKwaPELz9bdRXF8qYXdUYJ9hJIBp606596f6tzuQlOhdZghSitgyHjPk093MRAgXlO/er51a0SDiRD+Tu7hDFaNv9GU24PSeHWbngGXIBTnlpx0MfBadVpxV5YmCnvDgITJ6RsG2Sjal3hH0zIrGLfGel0/qP74xaNdIZwHHBuZrX4U+5ubrUy3NRRfvKN4JkABCcp1QrHZmdhAtOPfwUy7fmBf+SWLs0rCJkqRFWgToXtdORS8D7t6eC69q5yD14x4HKDOqlxcS99TiluPYSs12hPtR+aDAB0RaKWquWln8Ru1BzvW3vwBlpz45pgzUpEQvhmNI0nQi4gsHCs5cp0fOKQhfJBomYOEttboKp30y0o/XqMOLFoorso9O3Q0gU="

parameters={"tenantId":tenantId, "ace_orgGuid":team, "cloudOE_spaceGuid":namespace}
#tempPara=json.dumps([{"name": "access_key","default": "ASIAJUN5AVBNTQCKVX7A"}, {"name": "secret_key","default": "TqiCcT7RyQ+Xu5OhMfRAPeJKUbnhWyozKSwto2/+"}, {"name": "token","default": token}])
tempPara=[{"name": "access_key","value": "ASIAJUN5AVBNTQCKVX7A","type": "string"}, {"name": "secret_key","value": "TqiCcT7RyQ+Xu5OhMfRAPeJKUbnhWyozKSwto2/+","type": "string"}, {"name": "token","value": token,"type": "string"}]
tempParams=json.dumps(tempPara)
cloudconn=json.dumps([cloudConnectionId])
#cloudconn=[cloudConnectionId]
head = {"Authorization": "bearer " + access_token,'Content-Type': 'application/json', 'Accept':'application/json'} 
#postdata = {"name": "RestCall","cloud_connection_ids": cloudconn, "parameters": tempParams, "templateId": templateId,"forceCreate": "true" }
postdata = {
  "name": "TomcatRest",
  "cloud_connection_ids": [
     str(cloudConnectionId)
  ],
  "templateId": templateId,
  "parameters": [
     {
       "name": "access_key",
       "type": "string",
       "value": "ASIAIZFDP2H5N5AKKPKA"
     },
     {
       "name": "secret_key",
       "type": "string",
       "value": "I6nhvGMqTeUdIcQ1EUM+E1LpnO0MH4jsUyr9Xyqe"
     },
     {
       "name": "token",
       "type": "string",
       "value": token
     }
  ],
  "forceCreate": "true"
}
ret = requests.post(cam + "/cam/api/v1/stacks",  params=parameters, json=postdata, headers=head, verify=False)
responsepost=json.dumps(ret.json())
print("response", responsepost)

