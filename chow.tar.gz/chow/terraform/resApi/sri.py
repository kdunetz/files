import requests
import json

print("Cloud Automation Manager APIs - Python Script")

protocol='https://'
host='10.215.20.112'
camPort='30000'
icpPort='8443'
user='admin'
pw='admin'

cam=protocol + host + ":" + camPort
icp=protocol + host + ":" + icpPort

#get access token for cam
postdata = "grant_type=password&username=" + user + "&password=" + pw + "&scope=openid"
head = {'Content-Type':'application/x-www-form-urlencoded', 'Accept':'application/json', "charset" : "UTF-8"}
ret = requests.post(icp + "/idprovider/v1/auth/identitytoken", data=postdata, headers=head, verify=False)
access_token=ret.json()["access_token"]
print("access_token", access_token)

#GET tenantId, team and namespace from CAM
head = {"Authorization": "bearer " + access_token}
ret = requests.get(cam + "/cam/tenant/api/v1/tenants/getTenantOnPrem", headers=head, verify=False)
print("RET",ret.json())
tenantId = ret.json()["id"]
namespace = ret.json()["namespaces"][1]["uid"]
if user != 'admin': team = ret.json()["namespaces"][0]["teamId"]
else : team = 'all'
print("tenantId", tenantId)
print("team", team)
print("namespace", namespace)

#GET templates from CAM
parameters={"tenantId":tenantId, "ace_orgGuid":team}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/templates", headers=head, params=parameters, verify=False)
templates=json.dumps(ret.json())
#print("templates", templates)

#GET templates from CAM with name filter
parameters={"tenantId":tenantId, "ace_orgGuid":team, "filter":'{"where": {"name": "Tomcat" }}'}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/templates", headers=head, params=parameters, verify=False)
templates=json.dumps(ret.json())
print("templates", templates)
#templateId=json.dumps(ret.json()["templates"][0]["id"])
templateId=json.dumps(ret.json()[0]["id"])
print("templates", templateId)

#GET cloudconnections from CAM
parameters={"tenantId":tenantId, "ace_orgGuid":team}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/cloudconnections", headers=head, params=parameters, verify=False)
cloudConnections=json.dumps(ret.json())
connectionId=json.dumps(ret.json()[0]["id"])
print("cloudConnections", cloudConnections)
print("cloudConnections", connectionId)



#Deploy the template

