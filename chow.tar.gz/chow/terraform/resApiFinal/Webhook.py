from flask import Flask
import subprocess,os 

app = Flask(__name__)

if os.getenv("VCAP_APP_PORT"):
	port = int(os.getenv("VCAP_APP_PORT"))
else:
	port = 8080

@app.route('/',methods=['GET'])
def render_default():
    print "Invoket default path"
    tc = tomcat_init()
    return tc

@app.route('/tomcat',methods=['PUT','POST'])
def render_tomcat():
    print "Invoket tomcat  path"
    tc = tomcat_init()
    return tc

@app.route('/worker',methods=['PUT','POST'])
def render_worker():
    print "Invoket worker  path"
    work = worker_init()
    return work 

def tomcat_init():
    cmd = "python tomcat.py"
    #cmd = "ls -l"
    proc = subprocess.Popen(cmd,stdout=subprocess.PIPE,shell=True)
    for line in proc.stdout.readlines():
    	print "********"
    	print line
    	return line

def worker_init():
    cmd = "python worker.py"
    #cmd = "ls -l"
    proc = subprocess.Popen(cmd,stdout=subprocess.PIPE,shell=True)
    for line in proc.stdout.readlines():
    	print "********"
    	print line
    	return line
    
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=port,debug=True)

