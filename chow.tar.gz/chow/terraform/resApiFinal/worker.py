import requests
import json
import subprocess, random

print("Cloud Automation Manager APIs - Python Script")
protocol='https://'
host='10.215.20.112'
camPort='30000'
icpPort='8443'
user='admin'
pw='admin'

cam=protocol + host + ":" + camPort
icp=protocol + host + ":" + icpPort

#get access token for cam
postdata = "grant_type=password&username=" + user + "&password=" + pw + "&scope=openid"
head = {'Content-Type':'application/x-www-form-urlencoded', 'Accept':'application/json', "charset" : "UTF-8"}
ret = requests.post(icp + "/idprovider/v1/auth/identitytoken", data=postdata, headers=head, verify=False)
access_token=ret.json()["access_token"]
print("access_token", access_token)

#GET tenantId, team and namespace from CAM
#nned to fix this to ger right teantnt etc
head = {"Authorization": "bearer " + access_token}
ret = requests.get(cam + "/cam/tenant/api/v1/tenants/getTenantOnPrem", headers=head, verify=False)
print(ret.json())
tenantId = ret.json()["id"]
namespace = ret.json()["namespaces"][1]["uid"]
if user != 'admin': team = ret.json()["namespaces"][1]["teamId"]
else : team = 'all'
print("tenantId", tenantId)
print("team", team)
print("namespace", namespace)
namespace="default"

#GET templates from CAM with name filter
parameters={"tenantId":tenantId, "ace_orgGuid":team, "filter":'{"where": {"name": "WorkerNode" }}'}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/templates", headers=head, params=parameters, verify=False)
#templates=json.dumps(ret.json())
templateId=ret.json()[0]["id"]
#print("templates", templates)
print("template ID", templateId)

#GET cloudconnections from CAM
parameters={"tenantId":tenantId, "ace_orgGuid":team}
head = {"Authorization": "bearer " + access_token, 'Accept':'application/json'}
ret = requests.get(cam + "/cam/api/v1/cloudconnections", headers=head, params=parameters, verify=False)
cloudConnections=json.dumps(ret.json())
#print("cloudConnections", cloudConnections)
cloudConnectionId=ret.json()[0]["id"]
print("cloudConnections ID", cloudConnectionId)

#Run the script to get the tokens
#Run the java file to get the token
cmd = "/opt/jdk1.8.0_144-x86_64/bin/java -jar /opt/federated-access/federated-access-sts.jar >/tmp/token.out"
proc = subprocess.Popen(cmd,stdout=subprocess.PIPE,shell=True)
#even though nothing is printed we need to read the lines for the file to be created
for line in proc.stdout.readlines():
 print "********"
 print line

#parse the token and values from the script
cmd = "grep 'Token\|Access\|Secret' /tmp/token.out"
list = []
proc = subprocess.Popen(cmd,stdout=subprocess.PIPE, shell=True)
for line in proc.stdout.readlines():
    list.append(line)
print  list
access_key=list[0].split("::",1)[1].rstrip()
secret_key=list[1].split("::",1)[1].rstrip()
token=list[2].split("::",1)[1].rstrip()

print ("AccessKey",access_key)
print ("SecretKey",secret_key)
print ("Token",token)

#Random Name generate
first_names=('Alpha','Beta','Charlie','Delta','Echo','Foxtrot','Golf','Hotel')
last_names=('Adams','Boston','Chicago','Denver','Easy','Frank','George','Henry','Ida')
full_name=random.choice(first_names)+"-"+random.choice(last_names)+"-WK"
print full_name

#Deploy the template
parameters={"tenantId":tenantId, "ace_orgGuid":team, "cloudOE_spaceGuid":namespace}
head = {"Authorization": "bearer " + access_token,'Content-Type': 'application/json', 'Accept':'application/json'} 
postdata = {
  "name": full_name,
  "cloud_connection_ids": [
     str(cloudConnectionId)
  ],
  "templateId": templateId,
  "parameters": [
     {
       "name": "access_key",
       "type": "string",
       "value": access_key
     },
     {
       "name": "secret_key",
       "type": "string",
       "value": secret_key
     },
     {
       "name": "aws_instancetype",
       "type": "string",
       "value": "t2.medium" 
     },
     {
       "name": "token",
       "type": "string",
       "value": token
     }
  ],
  "forceCreate": "true"
}
ret = requests.post(cam + "/cam/api/v1/stacks",  params=parameters, json=postdata, headers=head, verify=False)
responsepost=json.dumps(ret.json())
print("response", responsepost)

